/******************** (C) COPYRIGHT 2015 FTC ***************************
 * ����		 ��FTC
 * �ļ���  ��FTC_Drv_LED.cpp
 * ����    ��LED
**********************************************************************************/
#include "FTC_Drv_LED.h"

FTC_LED led;

void FTC_LED::Init(void)
{
	//To do
}

void FTC_LED::ON1(void)
{
	//To do			
}

void FTC_LED::ON2(void)
{		
	//To do	
}

void FTC_LED::OFF1(void)
{
	//To do
}

void FTC_LED::OFF2(void)
{
	//To do	
}


/******************* (C) COPYRIGHT 2015 FTC *****END OF FILE************/

